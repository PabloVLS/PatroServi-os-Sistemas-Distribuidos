package com.example.patroservicosSD3;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatroservicosSd3Application {

	public static void main(String[] args) {
		SpringApplication.run(PatroservicosSd3Application.class, args);
	}

}
