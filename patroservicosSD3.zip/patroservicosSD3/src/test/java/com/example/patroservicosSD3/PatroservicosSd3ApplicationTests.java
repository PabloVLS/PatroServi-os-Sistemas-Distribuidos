package com.example.patroservicosSD3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PatroservicosSd3ApplicationTests {

	@Test
	void contextLoads() {
	}

}
