package com.example.patroservicosSDGestor;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatroservicosSdGestorApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatroservicosSdGestorApplication.class, args);
	}

}
