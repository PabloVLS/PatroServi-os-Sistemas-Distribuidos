package com.example.patroservicosSD;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PatroservicosSdApplication {

	public static void main(String[] args) {
		SpringApplication.run(PatroservicosSdApplication.class, args);
	}

}
